package com.sonu.service;

import java.lang.reflect.Type;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.stereotype.Service;

import com.sonu.dao.StockExchangeDao;
import com.sonu.dto.StockExchangeDto;
import com.sonu.model.StockExchangeEntity;

@Service
public class StockExchangeServiceImpl implements StockExchangeService{
	
	private StockExchangeDao stockExchangeDao;
	private ModelMapper modelMapper;
	


	public StockExchangeServiceImpl(StockExchangeDao stockExchangeDao, ModelMapper modelMapper) {
		super();
		this.stockExchangeDao = stockExchangeDao;
		this.modelMapper = modelMapper;
	}

	@Override
	public StockExchangeDto getStockExchangeById(Integer stockExchangeid) {
		// TODO Auto-generated method stub
		return modelMapper.map( stockExchangeDao.getStockExchange(stockExchangeid),StockExchangeDto.class);
	}

	@Override
	public StockExchangeDto addStockExchange(StockExchangeDto stockExchangeDto) {
		modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
		StockExchangeEntity stockExchangeEntity =stockExchangeDao.saveAndFlush(modelMapper.map(stockExchangeDto,StockExchangeEntity.class));
		// TODO Auto-generated method stub
		
		return modelMapper.map(stockExchangeEntity,StockExchangeDto.class);
	}

	@Override
	public void deleteStockExchange(Integer id) {
		// TODO Auto-generated method stub
		Integer sid=stockExchangeDao.getid(id);
		stockExchangeDao.deleteById(sid);
	}

	@Override
	public List<StockExchangeDto> getAllStockExchange() {
		// TODO Auto-generated method stub
		modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
        Type listType = new TypeToken<List<StockExchangeDto>>(){}.getType();
        List<StockExchangeDto> postDtoList = modelMapper.map(stockExchangeDao.findAll(),listType);
		return postDtoList;
	}

	@Override
	public Integer getId(Integer id) {
		// TODO Auto-generated method stub
		return stockExchangeDao.getid(id);
	}

}
