package com.sonu.service;

import java.util.List;

import org.springframework.data.repository.query.Param;

import com.sonu.dto.StockExchangeDto;

public interface StockExchangeService {

	public StockExchangeDto getStockExchangeById(@Param("username") Integer stockExchangeid);
	public StockExchangeDto addStockExchange(StockExchangeDto stockExchange);
	public void deleteStockExchange(Integer id);
	public List<StockExchangeDto> getAllStockExchange();
	public Integer getId(Integer id);
}
