package com.sonu.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.sonu.dto.StockExchangeDto;
import com.sonu.service.StockExchangeService;

@RestController
public class StockExchangeController {

	private StockExchangeService stockExchangeService;

	public StockExchangeController(StockExchangeService stockExchangeService) {
		super();
		this.stockExchangeService = stockExchangeService;
	}
	@GetMapping("/getStockExchange/{id}")
	public ResponseEntity<StockExchangeDto> getStockExchangeDetails( @PathVariable("id") Integer id){
		
		return new ResponseEntity<StockExchangeDto>( stockExchangeService.getStockExchangeById(id),HttpStatus.OK);
	}
	
	@PostMapping("/StockExchange")
	public ResponseEntity<StockExchangeDto> adduserDetails(@RequestBody StockExchangeDto stockExchangeDto){
		return new ResponseEntity<StockExchangeDto>(stockExchangeService.addStockExchange(stockExchangeDto), HttpStatus.CREATED);
	}
	
	@GetMapping("/getallStockExchange")
	public ResponseEntity<List<StockExchangeDto>> getAllStockExchangeDetails(){
		
		return new ResponseEntity<List<StockExchangeDto>>( stockExchangeService.getAllStockExchange(),HttpStatus.OK);
	}
	@DeleteMapping("/deleteStockExchange/{id}")
	public ResponseEntity<String> deleteStockExchangeDetails( @PathVariable("id") Integer id){
		stockExchangeService.deleteStockExchange(id);
		return new ResponseEntity<String> ( "Successfully Deleted",HttpStatus.OK);
	}
	@GetMapping("/getid/{id}")
	public ResponseEntity<Integer> getid( @PathVariable("id") Integer id){
		return new ResponseEntity<Integer>( stockExchangeService.getId(id),HttpStatus.OK);
	}
}
