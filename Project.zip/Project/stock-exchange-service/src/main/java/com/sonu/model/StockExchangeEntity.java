package com.sonu.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Data
@Getter
@Setter
@Entity
@NoArgsConstructor
@AllArgsConstructor
public class StockExchangeEntity {
	
	@javax.persistence.Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer id;
	
	private Integer stockexchangeid;
	private String stockexchange;
	private String brief;
	private String contactaddress;
	private String remark;
}
