package com.sonu.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.sonu.dto.StockExchangeDto;
import com.sonu.model.StockExchangeEntity;

public interface StockExchangeDao extends JpaRepository<StockExchangeEntity, Integer> {
	@Query( "SELECT a FROM StockExchangeEntity a WHERE stockexchangeid=:stockexchangeid")
	public StockExchangeEntity getStockExchange(@Param("stockexchangeid") Integer stockexchangeid);
	
	@Query( value="SELECT id FROM StockExchangeEntity a WHERE stockexchangeid = :stockexchangeid")
	public Integer getid(@Param("stockexchangeid") Integer stockexchangeid) ;
}
