package com.sonu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZullApplicationTests {

	@Test
	void contextLoads() {
	}

}
