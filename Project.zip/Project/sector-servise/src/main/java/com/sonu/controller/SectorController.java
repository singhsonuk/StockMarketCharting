package com.sonu.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.sonu.dto.SectorDto;
import com.sonu.service.SectorService;

@RestController
public class SectorController {

	private SectorService sectorService;

	public SectorController(SectorService sectorService) {
		super();
		this.sectorService = sectorService;
	}
	@PostMapping("/sectors")
	public ResponseEntity<SectorDto> adduserDetails(@RequestBody SectorDto sectorDto){
		return new ResponseEntity<SectorDto>(sectorService.addSector(sectorDto), HttpStatus.CREATED);
	}
	
	@GetMapping("/sectors")
	public ResponseEntity<List<SectorDto>> getAllStockExchangeDetails(){
		
		return new ResponseEntity<List<SectorDto>>(sectorService.getAllSector(),HttpStatus.OK);	
	}
	
	@GetMapping("/sector/{id}")
	public ResponseEntity<SectorDto> getsectorDetails( @PathVariable("id") Integer id){
		return new ResponseEntity<SectorDto>( sectorService.getSector(id),HttpStatus.OK);
	}
	
	@DeleteMapping("/deleteSector/{id}")
	public ResponseEntity<String> deleteStockExchangeDetails( @PathVariable("id") Integer id){
		sectorService.deleteSector(id);
		return new ResponseEntity<String> ( "Successfully Deleted",HttpStatus.OK);
	}
	@GetMapping("/getsectorid/{id}")
	public ResponseEntity<Integer> getid( @PathVariable("id") Integer id){
		
		return new ResponseEntity<Integer>( sectorService.getid(id),HttpStatus.OK);
	}
	
	
}

