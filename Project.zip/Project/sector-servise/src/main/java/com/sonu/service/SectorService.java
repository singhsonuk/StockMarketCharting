package com.sonu.service;

import java.util.List;

import com.sonu.dto.SectorDto;

public interface SectorService {

	public List<SectorDto> getAllSector();
	public SectorDto getSector(Integer sectorId);
	public void deleteSector(Integer id);
	public SectorDto addSector(SectorDto sectorDto);
	public Integer getid(Integer sectorid);
}
