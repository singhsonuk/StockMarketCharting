package com.sonu.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.sonu.entity.Sector;

public interface SectorDao  extends JpaRepository<Sector,Integer>{
	@Query( value="SELECT id FROM Sector a WHERE sectorid = :sectorid")
	public Integer getid(@Param("sectorid") Integer sectorid);
}
