package com.sonu.service;

import java.lang.reflect.Type;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.stereotype.Service;

import com.sonu.dao.SectorDao;
import com.sonu.dto.SectorDto;
import com.sonu.entity.Sector;

@Service
public class SectorServiceImpl implements SectorService{
	
	private SectorDao sectorDao;
	private ModelMapper modelMapper;
	

	public SectorServiceImpl(SectorDao sectorDao, ModelMapper modelMapper) {
		super();
		this.sectorDao = sectorDao;
		this.modelMapper = modelMapper;
	}

	@Override
	public List<SectorDto> getAllSector() {
		// TODO Auto-generated method stub
		modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
        Type listType = new TypeToken<List<SectorDto>>(){}.getType();
        List<SectorDto> postDtoList = modelMapper.map(sectorDao.findAll(),listType);
		return postDtoList;
	}

	@Override
	public SectorDto getSector(Integer sectorId) {
		// TODO Auto-generated method stub
		Integer id=sectorDao.getid(sectorId);
		return modelMapper.map(sectorDao.findById(id),SectorDto.class);
	}

	@Override
	public void deleteSector(Integer sectorid) {
		// TODO Auto-generated method stub
		Integer id=sectorDao.getid(sectorid);
		sectorDao.deleteById(id);
	}

	@Override
	public SectorDto addSector(SectorDto sectorDto) {
		// TODO Auto-generated method stub
		modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
		Sector user =sectorDao.saveAndFlush(modelMapper.map(sectorDto,Sector.class));
		return modelMapper.map(user,SectorDto.class);
	}

	@Override
	public Integer getid(Integer sectorid) {
		// TODO Auto-generated method stub
		return sectorDao.getid(sectorid);
	}

}
