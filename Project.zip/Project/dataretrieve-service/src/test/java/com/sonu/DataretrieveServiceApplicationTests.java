package com.sonu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataretrieveServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
