package com.sonu.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.sonu.dto.UserDto;
import com.sonu.service.AdminUserService;

@RestController
public class AdminUserController {
	private AdminUserService userService;

	public AdminUserController(AdminUserService userService) {
		super();
		this.userService = userService;
	}
	@GetMapping("/getadminuser/{username}/{password}")
	public ResponseEntity<UserDto> getUserDetails( @PathVariable("username") String username, @PathVariable("password") String password){
		
		return new ResponseEntity<UserDto>( userService.getUserDetails(username, password),HttpStatus.OK);
	}
	
	@PostMapping("/adminusers")
	public ResponseEntity<UserDto> adduserDetails(@RequestBody UserDto userDto){
		return new ResponseEntity<UserDto>(userService.addNewUser(userDto), HttpStatus.CREATED);
	}
	
	@GetMapping("/adminusers")
	public ResponseEntity<List<UserDto>> getAllUser(@RequestBody UserDto userDto){
		return new ResponseEntity<List<UserDto>>(userService.getAllUser(), HttpStatus.CREATED);
	}
	
	@DeleteMapping("/deleteadminuser/{username}/{password}")
	public ResponseEntity<String> deleteUser(@PathVariable("username") String username, @PathVariable("password") String password){
		Integer id=userService.getuserid(username, password);
		userService.deleteUser(id);
		return new ResponseEntity<String>("Successfully Deleted",HttpStatus.OK);
	}
	
	@GetMapping("/getadminid/{username}/{password}")
	public ResponseEntity<Integer> getUserid( @PathVariable("username") String username, @PathVariable("password") String password){
		return new ResponseEntity<Integer>( userService.getuserid(username, password),HttpStatus.OK);
	}
	
	@PostMapping("/updateadminuser/{username}/{password}")
	public ResponseEntity<UserDto> udateuser(@RequestBody UserDto userDto){
		return new ResponseEntity<UserDto>(userService.updateUser(userDto), HttpStatus.CREATED);
	}
}
