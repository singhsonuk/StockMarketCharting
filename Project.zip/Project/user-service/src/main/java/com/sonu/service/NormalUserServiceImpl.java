package com.sonu.service;

import java.lang.reflect.Type;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.stereotype.Service;

import com.sonu.dao.UserDao;
import com.sonu.dto.UserDto;
import com.sonu.model.UserEntity;


@Service
public class NormalUserServiceImpl implements NormalUserService {
	private UserDao userDao;
	private ModelMapper modelMapper;

	public NormalUserServiceImpl(UserDao userDao, ModelMapper modelMapper) {
		super();
		this.userDao = userDao;
		this.modelMapper = modelMapper;
	}

	@Override
	public UserDto addNewUser(UserDto userDto) {
		// TODO Auto-generated method stub
		modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
        UserEntity user =userDao.saveAndFlush(modelMapper.map(userDto,UserEntity.class));
		return modelMapper.map(user,UserDto.class);
	}

	@Override
	public void deleteUser( Integer id) {
		// TODO Auto-generated method stub
		userDao.deleteById(id);
	}

	@Override
	public UserDto updateUser(UserDto userDto) {
		modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
        UserEntity user =userDao.saveAndFlush(modelMapper.map(userDto,UserEntity.class));
		return modelMapper.map(user,UserDto.class);
	}

	@Override
	public UserDto getUserDetails(String username, String password) {
		UserEntity user =userDao.getUserByUserNameAndPassword(username, password);
		return modelMapper.map(user,UserDto.class);
	}

	@Override
	public List<UserDto> getAllUser() {
		// TODO Auto-generated method stub
		modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
        Type listType = new TypeToken<List<UserDto>>(){}.getType();
        List<UserDto> postDtoList = modelMapper.map(userDao.findAll(),listType);
		return postDtoList;
	}

	@Override
	public Integer getuserid(String username, String password) {
		// TODO Auto-generated method stub
		return userDao.getid(username, password);
	}

}
