package com.sonu.dto;


import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@Getter
@Setter
@NoArgsConstructor
public class UserDto {

	private String username;
	private String password;
	private String usertype;
	private String email;
	private Long number;
	private String conformed;
}
