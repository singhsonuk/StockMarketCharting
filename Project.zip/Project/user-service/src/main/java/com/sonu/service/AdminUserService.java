package com.sonu.service;

import java.util.List;

import com.sonu.dto.UserDto;

public interface AdminUserService {
	public UserDto addNewUser(UserDto userDto);
	public void deleteUser(Integer id);
	public UserDto updateUser(UserDto userDto);
	public UserDto getUserDetails(String username, String password);
	public List<UserDto> getAllUser();
	public Integer getuserid(String username, String password);
}
