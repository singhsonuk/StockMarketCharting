package com.sonu.dao;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.sonu.model.UserEntity;

public interface UserDao extends JpaRepository<UserEntity,Integer> {
	
	@Query( "SELECT a FROM UserEntity a WHERE username = :username AND password = :password")
	public UserEntity getUserByUserNameAndPassword(@Param("username") String username,@Param("password") String password);
//	@Query( value="DELETE FROM User_Entity WHERE username = :username AND password = :password",nativeQuery = true)
//	public UserEntity deleteByUserNameAndPassword(@Param("username") String username,@Param("password") String password);
	@Query( value="SELECT id FROM UserEntity a WHERE username = :username AND password = :password")
	public Integer getid(@Param("username") String username,@Param("password") String password) ;
}
