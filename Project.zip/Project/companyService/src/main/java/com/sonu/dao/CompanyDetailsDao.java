package com.sonu.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sonu.model.CompanyDetails;

public interface CompanyDetailsDao extends JpaRepository<CompanyDetails,String> {
	Optional<CompanyDetails> findByCompanyId(Integer companyId);
	List<CompanyDetails> findByCompanyNameContaining(String pattern);
}
