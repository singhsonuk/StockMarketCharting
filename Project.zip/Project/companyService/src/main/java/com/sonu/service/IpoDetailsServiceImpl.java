package com.sonu.service;

import org.springframework.stereotype.Service;

import com.sonu.dao.IpoDetailsDao;
import com.sonu.model.IpoDetails;

@Service
public class IpoDetailsServiceImpl implements IpoDetailsService {
	
	private IpoDetailsDao ipoDetailDao;
	


	public IpoDetailsServiceImpl(IpoDetailsDao ipoDetailDao) {
		super();
		this.ipoDetailDao = ipoDetailDao;
	}

	@Override
	public Iterable<IpoDetails> getIpoDetais() {
		// TODO Auto-generated method stub
		return ipoDetailDao.findAll();
	}

	@Override
	public IpoDetails addIpoDetail(IpoDetails ipoDetail) {
		// TODO Auto-generated method stub
		return ipoDetailDao.saveAndFlush(ipoDetail);
	}
	
}
