package com.sonu.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class IpoDetailsDto {
	private Integer ipoId;
	private String companyName;
	private String stockExchange;
	private float pricePerShare;
	private Integer noOfShares;
	private String openingDate;
	private String openingtime;
	public IpoDetailsDto(Integer ipoId, String companyName, String stockExchange, float pricePerShare,
			Integer noOfShares, String openingDate, String openingtime) {
		super();
		this.ipoId = ipoId;
		this.companyName = companyName;
		this.stockExchange = stockExchange;
		this.pricePerShare = pricePerShare;
		this.noOfShares = noOfShares;
		this.openingDate = openingDate;
		this.openingtime = openingtime;
	}
	public IpoDetailsDto() {
		super();
	}
}
