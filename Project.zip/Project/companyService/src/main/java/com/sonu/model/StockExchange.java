package com.sonu.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Getter
@Setter
@Entity
public class StockExchange {
	
	public StockExchange(Integer stockExchangeId, String stockExchange, String brief, String contactAddress,
			String remark) {
		super();
		StockExchangeId = stockExchangeId;
		this.stockExchange = stockExchange;
		this.brief = brief;
		this.contactAddress = contactAddress;
		Remark = remark;
	}
	@javax.persistence.Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer Id;
	
	private Integer StockExchangeId;
	private String stockExchange;
	private String brief;
	private String contactAddress;
	private String Remark;
}
