package com.sonu.dto;

import java.util.ArrayList;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CompanyDetailsDto {
	private Integer companyId;
	private String companyName;
	private String ceo;
	private String boardOfDirectors;
	
	private ArrayList<String> stockExchange;
	private Integer sector;
	private String description;
	private ArrayList<String> codeInStockExchange;
	public CompanyDetailsDto(Integer companyId, String companyName, String ceo, String boardOfDirectors,
			ArrayList<String> stockExchange, Integer sector, String description,
			ArrayList<String> codeInStockExchange) {
		super();
		this.companyId = companyId;
		this.companyName = companyName;
		this.ceo = ceo;
		this.boardOfDirectors = boardOfDirectors;
		this.stockExchange = stockExchange;
		this.sector = sector;
		this.description = description;
		this.codeInStockExchange = codeInStockExchange;
	}
	public CompanyDetailsDto() {
		super();
	}
	
}
