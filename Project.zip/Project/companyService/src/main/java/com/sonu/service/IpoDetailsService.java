package com.sonu.service;

import com.sonu.model.IpoDetails;

public interface IpoDetailsService {
	public Iterable<IpoDetails> getIpoDetais();
	
	public IpoDetails addIpoDetail(IpoDetails ipoDetails);
}
