package com.sonu.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.sonu.dto.CompanyDetailsDto;
import com.sonu.service.CompanyDetailsService;

@RestController
public class CustomerDetailsController {
	
	private CompanyDetailsService companyDetailsService;

	public CustomerDetailsController(CompanyDetailsService companyDetailsService) {
		super();
		this.companyDetailsService = companyDetailsService;
	}
	
	@GetMapping("/companies")
	public ResponseEntity<Iterable<CompanyDetailsDto>> getCompanyDetails(){
		
		return new ResponseEntity<Iterable<CompanyDetailsDto>>(companyDetailsService.getAllCompanyDetails(), HttpStatus.OK); 
	}
	
	@PostMapping("/companies")
	public ResponseEntity<CompanyDetailsDto> addCompany(@RequestBody CompanyDetailsDto companyDto) {
		return new ResponseEntity<CompanyDetailsDto>(companyDetailsService.addCompany(companyDto), HttpStatus.CREATED);
	}
	
	@PutMapping("/companies/update/{companyId}")
	public ResponseEntity<CompanyDetailsDto> updateCompany(@RequestBody CompanyDetailsDto companyDto,@PathVariable("companyId") Integer companyId){
		return new ResponseEntity<CompanyDetailsDto> (companyDetailsService.updateCompany(companyDto,companyId), HttpStatus.OK);
		
	}
	
	@DeleteMapping("/companies/delete/{companyId}")
	public ResponseEntity<String> deleteCompany(@PathVariable("companyId") Integer companyId){
		
		companyDetailsService.DeleteCompany(companyId);
		return new ResponseEntity<String>("Successfully Deleted!!!", HttpStatus.OK);
		
	}
	
	@GetMapping("/companies/findByPattern/{pattern}")
	public ResponseEntity<List<CompanyDetailsDto>> searchCompany(@PathVariable("pattern") String pattern)
	{
		return new ResponseEntity<List<CompanyDetailsDto>> (companyDetailsService.searchByPattern(pattern), HttpStatus.OK);
	}

}
