package com.sonu.service;

import com.sonu.dao.CompanyDetailsDao;
import com.sonu.dto.CompanyDetailsDto;
import com.sonu.model.CompanyDetails;

import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.stereotype.Service;

import java.lang.reflect.Type;
import java.util.List;

@Service
public class CompanyDetailsServiceImpl implements CompanyDetailsService {
	
	private CompanyDetailsDao companyDetailsDao;
	private ModelMapper modelMapper;


	public CompanyDetailsServiceImpl(CompanyDetailsDao companyDetailsDao, ModelMapper modelMapper) {
		super();
		this.companyDetailsDao = companyDetailsDao;
		this.modelMapper = modelMapper;
	}


	@Override
	public CompanyDetailsDto addCompany(CompanyDetailsDto companyDetalisDto) {
		// TODO Auto-generated method stub
		modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
        CompanyDetails company =companyDetailsDao.save(modelMapper.map(companyDetalisDto,CompanyDetails.class));
        return modelMapper.map(company,CompanyDetailsDto.class);
	}



	@Override
	public Iterable<CompanyDetailsDto> getAllCompanyDetails() {
		// TODO Auto-generated method stub
		modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
		Type listType = new TypeToken<List<CompanyDetailsDto>>(){}.getType();
		List<CompanyDetailsDto> postDtoList = modelMapper.map(companyDetailsDao.findAll(),listType);
		return postDtoList;
	}


	@Override
	public void DeleteCompany(Integer companyId) {
		// TODO Auto-generated method stub
		CompanyDetails company = companyDetailsDao.findByCompanyId(companyId).get();
		companyDetailsDao.delete(company);
	}


	@Override
	public CompanyDetailsDto updateCompany(CompanyDetailsDto companyDto, Integer companyId) {
		// TODO Auto-generated method stub
		CompanyDetails company = companyDetailsDao.findByCompanyId(companyId).get();
		company.setCompanyName(companyDto.getCompanyName());
		company.setCeo(companyDto.getCeo());
		company.setBoardOfDirectors(companyDto.getBoardOfDirectors());
		company.setDescription(companyDto.getDescription());
		company.setSector(companyDto.getSector());
		company.setStockExchange(companyDto.getStockExchange());
		company.setCodeInStockExchange(companyDto.getCodeInStockExchange());
		companyDetailsDao.save(company);
		modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
		return modelMapper.map(company,CompanyDetailsDto.class);
	}


	@Override
	public List<CompanyDetailsDto> searchByPattern(String pattern) {
		// TODO Auto-generated method stub
		modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
        Type listType = new TypeToken<List<CompanyDetailsDto>>(){}.getType();
        List<CompanyDetailsDto> postDtoList = modelMapper.map(companyDetailsDao.findByCompanyNameContaining(pattern),listType);
        return postDtoList;
	}


}
