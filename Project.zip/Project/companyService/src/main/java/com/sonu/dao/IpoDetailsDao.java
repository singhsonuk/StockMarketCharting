package com.sonu.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sonu.model.IpoDetails;

public interface IpoDetailsDao extends JpaRepository<IpoDetails,String> {
}
