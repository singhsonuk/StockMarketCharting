package com.sonu.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.sonu.dto.CompanyDetailsDto;

public interface CompanyDetailsService {
	public CompanyDetailsDto  addCompany(CompanyDetailsDto companyDetalisDto);
	//public CompanyDetailsDto getCompanyDetailsByCompanyId(Integer companyId);
	public void DeleteCompany(Integer companyId);
	public Iterable<CompanyDetailsDto> getAllCompanyDetails();
	public CompanyDetailsDto updateCompany(CompanyDetailsDto companyDto, Integer companyId);
	public List<CompanyDetailsDto> searchByPattern(String pattern);
	
}
