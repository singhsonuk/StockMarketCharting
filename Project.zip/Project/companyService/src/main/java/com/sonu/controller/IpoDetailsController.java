package com.sonu.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.sonu.model.IpoDetails;
import com.sonu.service.IpoDetailsService;

public class IpoDetailsController {
	private IpoDetailsService ipoDetailService;


	public IpoDetailsController(IpoDetailsService ipoDetailService) {
		super();
		this.ipoDetailService = ipoDetailService;
	}

	@GetMapping("/ipoDetails/{companyName}")
	public ResponseEntity<Iterable<IpoDetails>> getIpoDetails(){
		
		return new ResponseEntity<Iterable<IpoDetails>>(ipoDetailService.getIpoDetais(), HttpStatus.OK); 
	}
	
	@PostMapping("/ipoDetails/{companyName}")
	public ResponseEntity<IpoDetails> addIpoDetail(@RequestBody IpoDetails ipoDetail) {
		return new ResponseEntity<IpoDetails>(ipoDetailService.addIpoDetail(ipoDetail), HttpStatus.CREATED);
		
	}
}
