package com.sonu.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.Data;
import lombok.Generated;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@Getter
@Setter
@Entity
public class IpoDetails {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer id;
	
	private Integer ipoId;
	private String companyName;
	private String stockExchange;
	private float pricePerShare;
	private Integer noOfShares;
	private String openingDate;
	private String openingtime;
	public IpoDetails(Integer ipoId, String companyName, String stockExchange, float pricePerShare, Integer noOfShares,
			String openingDate, String openingtime) {
		super();
		this.ipoId = ipoId;
		this.companyName = companyName;
		this.stockExchange = stockExchange;
		this.pricePerShare = pricePerShare;
		this.noOfShares = noOfShares;
		this.openingDate = openingDate;
		this.openingtime = openingtime;
	}
	public IpoDetails() {
		super();
	}
	
	
}
