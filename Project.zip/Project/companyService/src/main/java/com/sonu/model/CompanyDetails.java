package com.sonu.model;

import java.util.ArrayList;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import antlr.collections.List;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Data
@Getter
@Setter
@NoArgsConstructor
public class CompanyDetails {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer id;
	
	private Integer companyId;
	private String companyName;
	private String ceo;
	private String boardOfDirectors;
	
	private ArrayList<String> stockExchange;
	private Integer sector;
	private String description;
	private ArrayList<String> codeInStockExchange;
	
}
